#app example_0, Version="1.0.0.0", Author=Zalexanninev15, Command=/simple

function MainFunc($arg1, $arg2, $arg3, $arg4) {
    Write "Привет Мир! Ниже идёт тестовый подсчёт (3+4)"
	3+4
}